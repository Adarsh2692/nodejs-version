const express = require('express');
const open = require('open');
const cp = require('child_process');
const sqlite3 = require('sqlite3').verbose();
const app = express();
const port = 3000;

var db = new sqlite3.Database('C:/Users/Adarsh/Desktop/Browser/History');

app.get('/start/:browser/:url', async (req, res) => {
    const browser = req.params.browser;
    const url = req.params.url;
    await open(url, { app: { name: browser } });
    res.send(req.params.browser);
});

app.get('/stop/:browser', async (req, res) => {
    const browser = req.params.browser;
    if (browser === 'firefox') cp.exec('taskkill /f /im firefox.exe');
    else cp.exec('taskkill /f /im chrome.exe');
    res.send(req.params.browser);
});

app.get('/history', async (req, res) => {
    db.serialize(function () {
        db.all('SELECT * FROM urls ORDER BY id DESC LIMIT 10;', function (err, rows) {
            console.log(rows);
        });
    });
});

app.get('/delete', async (req, res) => {
    
});

app.listen(port, () => {
    console.log(`Example app listening on port ${port}`);
});
